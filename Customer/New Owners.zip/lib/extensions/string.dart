extension NumberParsing on String {
  double toDouble() {
    return double.parse(this.toString());
  }
}