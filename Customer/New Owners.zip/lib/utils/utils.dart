import 'package:i18n_extension/i18n_widget.dart';

class Utils{

  static bool get isArabic => I18n.language == "ar";
}