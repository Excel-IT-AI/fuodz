import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_background/flutter_background.dart';
import 'package:fuodz/constants/app_strings.dart';
import 'package:fuodz/services/app.service.dart';
import 'package:fuodz/services/location.service.dart';
import 'package:fuodz/widgets/bottomsheets/background_permission.bottomsheet.dart';
import 'package:fuodz/translations/background_service.i18n.dart';
import 'package:background_location/background_location.dart';
import 'package:location/location.dart';

class AppbackgroundService {
  static void startBg() async {
    //
    if (!Platform.isAndroid) {
      return;
    }
    //
    final androidConfig = FlutterBackgroundAndroidConfig(
      notificationTitle: "Background service".i18n,
      notificationText: "Background notification to keep app running".i18n,
      notificationImportance: AndroidNotificationImportance.Default,
      notificationIcon: AndroidResource(
        name: 'notification_icon',
        defType: 'drawable',
      ), // Default is ic_launcher from folder mipmap
    );

    //check for permission
    bool hasPermissions = await FlutterBackground.hasPermissions;
    if (!hasPermissions) {
      await showDialog(
        context: AppService().navigatorKey.currentContext,
        builder: (context) {
          return BackgroundPermissionDialog(
            onResult: (result) {
              if (result == null || !result) {
                return;
              }
            },
          );
        },
      );

      //

    }

    await FlutterBackground.initialize(androidConfig: androidConfig);
    await FlutterBackground.enableBackgroundExecution();

    //location backgound location
    BackgroundLocation.setAndroidNotification(
      title: "Location Background service".i18n,
      message: "Location service is running when app is open/minimised".i18n,
      icon: "@mipmap/notification_icon",
    );
    //
    BackgroundLocation.setAndroidConfiguration(AppStrings.timePassLocationUpdate);
    BackgroundLocation.startLocationService(distanceFilter: AppStrings.distanceCoverLocationUpdate);
    BackgroundLocation.getLocationUpdates((location) {
      LocationData locationData = LocationData.fromMap(location.toMap());
      LocationService.syncLocationWithFirebase(locationData);
      print("Background location ==> $location");
      print("Background location Data ==> $location");
    });
  }

  static void stopBg() {
    if (!Platform.isAndroid) {
      return;
    }
    bool enabled = FlutterBackground.isBackgroundExecutionEnabled;
    if (enabled) {
      FlutterBackground.disableBackgroundExecution();
      BackgroundLocation.stopLocationService();
    }
  }
}
