import 'package:flutter/material.dart';
import 'package:fuodz/constants/app_colors.dart';
import 'package:fuodz/models/order.dart';
import 'package:fuodz/view_models/order_signature_verification.vm.dart';
import 'package:fuodz/widgets/base.page.dart';
import 'package:fuodz/widgets/buttons/custom_button.dart';
import 'package:hand_signature/signature.dart';
import 'package:stacked/stacked.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:fuodz/translations/order_details.i18n.dart';

class SignatureVerificationPage extends StatefulWidget {
  SignatureVerificationPage({this.order, Key key}) : super(key: key);

  //
  final Order order;
  @override
  _SignatureVerificationPageState createState() =>
      _SignatureVerificationPageState();
}

class _SignatureVerificationPageState extends State<SignatureVerificationPage> {
  @override
  Widget build(BuildContext context) {
    return BasePage(
      showAppBar: true,
      showLeadingAction: true,
      title: "Order Verification".i18n,
      body: ViewModelBuilder<OrderSignatureVerificationViewModel>.reactive(
        viewModelBuilder: () => OrderSignatureVerificationViewModel(
          context,
          widget.order,
        ),
        onModelReady: (vm) => vm.initialise(),
        builder: (context, vm, child) {
          return VStack(
            [
              "Customer signature".i18n.text.semiBold.xl.make(),
              //
              HandSignaturePainterView(
                control: vm.handSignatureControl,
                color: AppColor.primaryColor,
                width: 2.0,
                maxWidth: 10.0,
                type: SignatureDrawType.line,
              )
                  .wFull(context)
                  .hTwoThird(context)
                  .box
                  .roundedSM
                  .border()
                  .make()
                  .py12(),

              //
              CustomButton(
                title: "Submit".i18n,
                loading: vm.isBusy,
                onLongPress: vm.submitSignature,
              ).wFull(context),
              "Long press to submit".i18n.text.lg.makeCentered().py8(),
            ],
          ).p20();
        },
      ),
    );
  }
}
