import 'package:flutter/material.dart';
import 'package:fuodz/constants/app_strings.dart';
import 'package:fuodz/services/app.service.dart';
import 'package:fuodz/utils/ui_spacer.dart';
import 'package:fuodz/widgets/buttons/custom_button.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:fuodz/translations/background_service.i18n.dart';

class BackgroundPermissionDialog extends StatelessWidget {
  const BackgroundPermissionDialog({Key key, this.onResult}) : super(key: key);

  //
  final Function(bool) onResult;

  //
  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: VStack(
        [
          //title
          "Background Permission Request".i18n.text.semiBold.xl.make().py12(),
          ("${AppStrings.appName} " +
                  "requires your background permission to enable app receive new order notification even when app is in background"
                      .i18n)
              .text
              .make(),
          UiSpacer.verticalSpace(),
          CustomButton(
            title: "Next".i18n,
            onPressed: () {
              onResult(true);
              AppService().navigatorKey.currentContext.pop();
            },
          ).py12(),
          CustomButton(
            title: "Cancel".i18n,
            color: Colors.grey[400],
            onPressed: () {
              onResult(false);
              AppService().navigatorKey.currentContext.pop();
            },
          ),
        ],
      ).p20().wFull(context).scrollVertical(), //.hTwoThird(context),
    );
  }
}
